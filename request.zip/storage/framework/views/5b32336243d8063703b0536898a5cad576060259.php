

<?php $__env->startSection('content'); ?>
        <div class="row mb-2">
            <div class="col-12">
            <div class="card mini-stats-wid px-4 py-4">
                <div class="card-body">
                    <div class="media mb-4 text-center">
                        <div class="media-body">
                            <h1 class="fw-large">Panduan Request <?php echo e($layanan->layanan); ?></h1>
                            <h4 class="mb-0"></h4>
                        </div>
                    </div>
                    <div class="row mt-4 py-4">
                        <div class="col-12">
                            <?php echo $layanan->deskripsi; ?>

                        </div>
                    </div>
                    <a href="<?php echo e(url('layanan/request', $layanan->id)); ?>" class="btn btn-primary">Buat Request</a>
                </div>
            </div>
        </div> 
    </div>
   
    <script language="JavaScript">
    </script>
    <?php $__env->stopSection(); ?>
    </body>
</html>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imamn\Documents\Laravel\SSO\resources\views/frontpage/detail_layanan.blade.php ENDPATH**/ ?>