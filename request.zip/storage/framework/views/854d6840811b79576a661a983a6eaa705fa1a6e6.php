

<?php $__env->startSection('content'); ?>
        <div class="row mb-2">
            <div class="col-12">
            <div class="row">
                <div class="col-12">
                    <div class="card py-4">
                        <div class="card-body text-center">
                        <h4 class="fw-medium mb-2">Request #<?php echo e($request->id); ?></h4>
                        <p>Tanggal dibuat : <?php echo e($request->created_at); ?></p>
                        <button type="button" class="btn <?php if($request->status=='Menunggu Persetujuan'): ?> btn-warning <?php elseif($request->status=='Ditolak'): ?> btn-danger <?php else: ?> btn-success <?php endif; ?> btn-sm btn-rounded waves-effect waves-light"><?php echo e($request->status); ?></button><br/>
                        </div>
                    </div>
                </div> <!-- end col -->
                <div class="col-12">
                <div class="card">
                    <div class="card-body">
                    <form action="<?php echo e(url('update-request')); ?>" method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                        <!-- Nav tabs -->
                        <!-- Tab panes -->
                        <div class="tab-content p-3 text-muted">
                            <div class="tab-pane active" id="home1" role="tabpanel">
                            <div class="row">
                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="basicpill-lastname-input">Requester</label>
                                            <input type="text" readonly name="name" value="<?php echo e($request->user->name); ?>" class="form-control" required="">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="mb-3">
                                            <label for="basicpill-lastname-input">Layanan</label>
                                            <input type="text" readonly  name="email" value="<?php echo e($request->layanan->layanan); ?>" class="form-control" required="">
                                        </div>
                                    </div>
                                    <?php $__currentLoopData = $request->layanan->fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-12 mb-2">
                                        <?php $__currentLoopData = $request->meta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($row->nama == $row2->nama): ?>
                                                <?php if($row->jenis == 'input'): ?>
                                                    <label for="basicpill-lastname-input"><?php echo e($row->label); ?></label><br/>
                                                    <?php if($row->tipe=='file'): ?>
                                                    <button class="btn btn-light btn-pdf" data-file="<?php echo e(url('')); ?>/uploads/<?php echo e($row2->value); ?>"  data-title="<?php echo e($row->label); ?>" type="button">Lihat File</button>
                                                    <input type="<?php echo e($row->tipe); ?>"  name="<?php echo e($row->nama); ?>" value="<?php echo e($row2->value); ?>" class="form-control mt-3">
                                                    <?php else: ?>
                                                    <input type="<?php echo e($row->tipe); ?>"  name="<?php echo e($row->nama); ?>" value="<?php echo e($row2->value); ?>" class="form-control" required="">
                                                    <?php endif; ?>
                                                <?php elseif($row->jenis == 'textarea'): ?>
                                                    <label for="basicpill-lastname-input"><?php echo e($row->label); ?></label>
                                                    <textarea  name="<?php echo e($row->nama); ?>" class="form-control" id="" cols="30" rows="5"><?php echo e($row2->value); ?></textarea>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <input type="hidden" name="request_id" value="<?php echo e($request->id); ?>">
                            <input type="hidden" name="layanan_id" value="<?php echo e($request->layanan->id); ?>">
                            <input type="hidden" name="status" value="Menunggu Persetujuan">
                            <button class="btn btn-primary mt-2" type="submit">Ajukan Kembali</button>
                        </div>
                    </form>
                    </div>
                </div>
                </div>
            </div> <!-- end row -->
            <!-- end row -->
    
            <div class="offcanvas offcanvas-end"  tabindex="-1" id="offcanvasScrolling" aria-modal="true" aria-labelledby="offcanvasScrollingLabel" role="dialog">
                <div class="offcanvas-header">
                    <h5 class="offcanvas-title" id="offcanvasScrollingLabel"></h5>
                    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                </div>
                <div class="offcanvas-body">
                    <iframe id="link" src="" style="width:100%; height:100vh;" frameborder="0"></iframe>
                </div>
            </div>

           

                
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('script'); ?>
    <script>
        var table = $('#datatable2').DataTable({
            "order": [[ 0, "desc" ]],
        });

        $('.btn-pdf').on('click', function(){
            var src = $(this).data('file');
            var title = $(this).data('title');
            $('#offcanvasScrollingLabel').text(title);
            $('#link').attr('src', src);
            $('#offcanvasScrolling').offcanvas('show');
        });

    </script>
    <?php $__env->stopSection(); ?>
    </body>
</html>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imamn\Documents\Laravel\SSO\resources\views/requester/request_detail.blade.php ENDPATH**/ ?>