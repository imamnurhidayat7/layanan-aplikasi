

<?php $__env->startSection('content'); ?>
        <div class="row mb-2">
            <div class="col-12">
            <div class="card mini-stats-wid">
                <div class="card-body">
                    <div class="media">
                        <div class="media-body">
                            <h4 class="fw-medium">Daftar Tamu Hari Ini</h4>
                            <h4 class="mb-0"></h4>
                <a href="<?php echo e(url('/')); ?>" class="btn btn-primary mt-2 waves-effect waves-light btn-sm">Input Buku Tamu<i class="mdi mdi-arrow-right ms-1"></i></a>
                        </div>

                        <div class="align-self-center">
                            
                                <img src="https://www.atrbpn.go.id/cms/assets/upload/kantor_1/kantor/20211014221502.png" height="50px" width="auto" alt="">
                            
                        </div>
                    </div>
                </div>
            </div>
            </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                        <table id="datatable" class="table table-bordered dt-responsive  nowrap w-100">
                        <thead>
                            <tr>
                            <th>Foto</th>
                            <th>Nama</th>
                            <th>NIK</th>
                            <th>Perusahaan</th>
                            <th>Keperluan</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $tamu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><img src="<?php echo e(asset('foto')); ?>/<?php echo e($row->foto); ?>" width="100px" alt=""></td>
                                <td><?php echo e($row->nama); ?></td>
                                <td><?php echo e($row->nik); ?></td>
                                <td><?php echo e($row->perusahaan); ?></td>
                                <td><?php echo e($row->keperluan); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->
            </form>
            <!-- end row -->
    </div> <!-- content -->
    <?php $__env->stopSection(); ?>
    </body>
</html>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imamn\Documents\Laravel\bukutamu\resources\views/frontpage/daftar_tamu.blade.php ENDPATH**/ ?>