<?php $__env->startSection('content'); ?>
        <div class="row mb-2">
            <div class="col-12">
            <div class="card mini-stats-wid">
                <div class="card-body">
                    <div class="media">
                        <div class="media-body">
                            <h4 class="fw-medium">Buku Tamu Pusdatin ATR BPN</h4>
                            <h4 class="mb-0"></h4>
                <a href="<?php echo e(url('admin/tamu')); ?>" class="btn btn-primary mt-2 waves-effect waves-light btn-sm">Lihat Daftar Tamu<i class="mdi mdi-arrow-right ms-1"></i></a>
                        </div>

                        <div class="align-self-center">
                            
                                <img src="https://www.atrbpn.go.id/cms/assets/upload/kantor_1/kantor/20211014221502.png" height="50px" width="auto" alt="">
                            
                        </div>
                    </div>
                </div>
            </div>
            </div>
            </div>

            <form method="POST" action="<?php echo e(url('input-data-tamu')); ?>" autocomplete="off"><?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                        <div class="row">
                            <div class="col-12">
                                <div class="row">
                                    <div class="col">
                                        
                                    </div>  
                                </div>
                            </div>     
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label>Nama</label>
                                    <input type="text" name="nama" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label>NIK</label>
                                    <input type="text" name="nik" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label>No HP</label>
                                    <input type="text" name="no_hp" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label>Email</label>
                                    <input type="text" name="email" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label>Perusahaan / Lembaga</label>
                                    <input type="text" name="perusahaan" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label>Pekerjaan</label>
                                    <input type="text" name="pekerjaan" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-3">
                                    <label>Keperluan</label>
                                    <textarea name="keperluan" id="" rows="6" class="form-control"></textarea>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="mb-1">
                                    <label>Foto</label>
                                    <div id="results">
                                        <img src="<?php echo e(asset('images/default-image.jpg')); ?>" alt="" width="160" height="110">
                                    </div>
                                </div>
                                <input type="hidden" name="foto" class="image-tag">
                                <input type="button" id="btnOpenCamera" class="btn btn-sm btn-primary" value="Buka Kamera" onClick="open_camera()">
                                <input type="button" id="btnTryAgain" class="btn btn-sm btn-danger hidden" value="Ulangi Ambil Foto" onClick="open_camera()">
                            </div>
                            <div class="col-lg-6">
                                <div class="form-check form-check-primary mb-3">
                                    <input class="form-check-input" name="lantai3" type="checkbox" id="formCheckcolor1">
                                    <label class="form-check-label" for="formCheckcolor1">
                                        Pengunjung Lantai 3
                                    </label>
                                </div>
                            </div>
                            <div class="col-md-12 mt-3">
                                <button type="submit" class="btn btn-success">Simpan</button>
                            </div>  
                        </div>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->
            </form>
            <!-- end row -->
    </div> <!-- content -->

    <div id="myModal" class="modal" tabindex="-1" aria-labelledby="myModalLabel" aria-modal="true" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="myModalLabel">Ambil Foto</h5>
                    <button type="button" class="btn-close" onClick="cancel()" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <center><div id="camera" class="text-center"></div></center>
                </div>
                <div class="modal-footer">
                    <input type="button" class="btn btn-secondary waves-effect" value="Batal" onClick="cancel()">
                    <input type="button" id="btnTakePhoto" class="btn btn-success hidden" value="Ambil Foto" onClick="take_snapshot()">
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>
   
    <script language="JavaScript">

        function open_camera(){
            $('#myModal').modal('show');
            Webcam.set({
                width: 320,
                height: 240,
                image_format: 'jpeg',
                jpeg_quality: 100,
                flip_horiz: true,
            });
            Webcam.attach('#camera');
            $('#btnTakePhoto').removeClass('hidden');
        }
    
        function take_snapshot() {
            Webcam.snap( function(data_uri) {
                $(".image-tag").val(data_uri);
                document.getElementById('results').innerHTML = '<img src="'+data_uri+'"" width="150" height="110"/>';
                $('#myModal').modal('hide');
                $('#btnOpenCamera').val('Ulangi Ambil Foto')
                //$('#btnTryAgain').removeClass('hidden');
            } );
            Webcam.reset();
        }

        function cancel(){
            $('#myModal').modal('hide');
            $('#btnOpenCamera').removeClass('hidden');
            Webcam.reset();
        }
    </script>
    <?php $__env->stopSection(); ?>
    </body>
</html>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imamn\Documents\Laravel\bukutamu\resources\views/frontpage/home.blade.php ENDPATH**/ ?>