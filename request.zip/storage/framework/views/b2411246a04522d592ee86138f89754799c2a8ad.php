

<?php $__env->startSection('content'); ?>
        <div class="row mb-2">
            <div class="col-12">
            <div class="card mini-stats-wid">
                <div class="card-body">
                    <div class="media">
                        <div class="media-body">
                            <h4 class="fw-medium">Daftar Tamu Lantai 3 Hari Ini</h4>
                            <h4 class="mb-0"></h4>
                <a href="<?php echo e(url('/')); ?>" class="btn btn-primary mt-2 waves-effect waves-light btn-sm">Input Buku Tamu<i class="mdi mdi-arrow-right ms-1"></i></a>
                        </div>

                        <div class="align-self-center">
                            
                                <img src="https://www.atrbpn.go.id/cms/assets/upload/kantor_1/kantor/20211014221502.png" height="50px" width="auto" alt="">
                            
                        </div>
                    </div>
                </div>
            </div>
            </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                        <table id="datatable" class="table table-bordered dt-responsive  nowrap w-100">
                        <thead>
                            <tr>
                            <th>Foto</th>
                            <th>Nama</th>
                            <th>NIK</th>
                            <th>Perusahaan</th>
                            <th>Keperluan</th>
                            <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $tamu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><img src="<?php echo e(asset('foto')); ?>/<?php echo e($row->foto); ?>" width="100px" alt=""></td>
                                <td><?php echo e($row->nama); ?></td>
                                <td><?php echo e($row->nik); ?></td>
                                <td><?php echo e($row->perusahaan); ?></td>
                                <td><?php echo e($row->keperluan); ?></td>
                                <td>
                                <a class="btn btn-success waves-effect waves-light btnEdit" data-id="<?php echo e($row->id); ?>" data-kegiatan="<?php echo e($row->kegiatan); ?>" data-barang_masuk="<?php echo e($row->barang_masuk); ?>" data-barang_keluar="<?php echo e($row->barang_keluar); ?>" data-pengawas="<?php echo e($row->pengawas); ?>" role="button"><i class="mdi mdi-pencil d-block font-size-16"></i> </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->
            </form>
            <!-- end row -->
    </div> <!-- content -->

    <!-- Static Backdrop Modal -->
    <div class="modal fade" id="modalEdit" data-bs-backdrop="static" data-bs-keyboard="false"
        tabindex="-1" role="dialog" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
        <form action="<?php echo e(url('/update-data-tamu')); ?>" method="post"><?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="staticBackdropLabel">Update Data Tamu</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12 mb-3">
                                <label>Barang Masuk</label>
                                <textarea class="form-control" name="barang_masuk" id="barang_masuk" rows="2"></textarea>
                        </div>
                        <div class="col-md-12 mb-3">
                                <label>Barang Keluar</label>
                                <textarea class="form-control" name="barang_keluar" id="barang_keluar" rows="2"></textarea>
                        </div>
                        <div class="col-md-12 mb-3">
                                <label>Kegiatan</label>
                                <textarea class="form-control" name="kegiatan" id="kegiatan" rows="2"></textarea>
                        </div>
                        <div class="col-md-12 mb-3">
                                <label>Pengawas</label>
                                <select name="pengawas" id="pengawas" class="form-control">
                                    <option value="">Pilih Pengawas</option>
                                    <?php $__currentLoopData = $pengawas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($row->id); ?>"><?php echo e($row->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <input type="hidden" name="id" id="edit_id">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </div>
        </form>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('script'); ?>
    <script>
        $(".btnEdit").on('click', function (){
            var id = $(this).data("id");
            var barang_masuk = $(this).data("barang_masuk");
            var barang_keluar = $(this).data("barang_keluar");
            var pengawas = $(this).data("pengawas");
            var kegiatan = $(this).data("kegiatan");

            $('#edit_id').val(id);
            $('#barang_masuk').val(barang_masuk);
            $('#barang_keluar').val(barang_keluar);
            $('#pengawas').val(pengawas);
            $('#kegiatan').val(kegiatan);
            $('#modalEdit').modal('show');
        });
    </script>
    <?php $__env->stopSection(); ?>
    </body>
</html>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imamn\Documents\Laravel\bukutamu\resources\views/frontpage/daftar_tamu_lt3.blade.php ENDPATH**/ ?>