

<?php $__env->startSection('content'); ?>
        <div class="row mb-2">
            <div class="col-12">
            <div class="card mini-stats-wid px-4 py-4">
                <div class="card-body">
                    <div class="media mb-4 text-center">
                        <div class="media-body">
                            <h3 class="fw-large">Form Request <?php echo e($layanan->layanan); ?></h3>
                            <h4 class="mb-0"></h4>
                        </div>
                    </div>
                    <form action="<?php echo e(url('tambah-request')); ?>" method="post" enctype="multipart/form-data"><?php echo csrf_field(); ?>
                    <div class="row mt-4 py-4">
                        <?php $__currentLoopData = $field; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12 mb-2">
                            <?php if($row->jenis == 'input'): ?>
                                <label for="basicpill-lastname-input"><?php echo e($row->label); ?></label>
                                <input type="<?php echo e($row->tipe); ?>" name="<?php echo e($row->nama); ?>" class="form-control" required="">
                            <?php elseif($row->jenis == 'textarea'): ?>
                                <label for="basicpill-lastname-input"><?php echo e($row->label); ?></label>
                                <textarea name="<?php echo e($row->nama); ?>" class="form-control" id="" cols="30" rows="5"></textarea>
                            <?php endif; ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <input type="hidden" name="id" value="<?php echo e($layanan->id); ?>">
                    <button class="btn btn-primary" type="submit">Submit</button>
                    </form>
                </div>
            </div>
        </div> 
    </div>
   
    <script language="JavaScript">
    </script>
    <?php $__env->stopSection(); ?>
    </body>
</html>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imamn\Documents\Laravel\SSO\resources\views/request/add.blade.php ENDPATH**/ ?>