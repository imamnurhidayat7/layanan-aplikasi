

<?php $__env->startSection('content'); ?>
        <div class="row mb-2">
            <div class="col-12">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                        <h4 class="fw-medium mb-4 text-center">Data Tamu Pusdatin ATR/BPN</h4>
                        
                        <div class="form-check form-check-primary mb-3">
                            <input class="form-check-input" name="lantai3" type="checkbox" id="checkboxlantai3">
                            <label class="form-check-label" for="formCheckcolor1">
                                Pengunjung Lantai 3
                            </label>
                        </div>
                    
                            
                        <table id="datatable2" class="table table-bordered dt-responsive  nowrap w-100">
                        <thead>
                            <tr>
                            <th>Tanggal</th>
                            <th>Foto</th>
                            <th>Nama</th>
                            <th>NIK</th>
                            <th>Perusahaan</th>
                            <th>Keperluan</th>
                            <th>Lantai 3</th>
                            <th>Pengawas</th>
                            <th>Barang Masuk</th>
                            <th>Barang Keluar</th>
                            <th>Kegiatan</th>
                            <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $tamu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($row->tanggal); ?></td>
                                <td><img src="<?php echo e(asset('foto')); ?>/<?php echo e($row->foto); ?>" width="100px" alt=""></td>
                                <td><?php echo e($row->nama); ?></td>
                                <td><?php echo e($row->nik); ?></td>
                                <td><?php echo e($row->perusahaan); ?></td>
                                <td><?php echo e($row->keperluan); ?></td>
                                <td><?php if($row->lantai3 == 1): ?> Ya <?php else: ?> Tidak <?php endif; ?></td>
                                <td><?php if($row->pengawas2): ?> <?php echo e($row->pengawas2->nama); ?> <?php endif; ?></td>
                                <td><?php echo e($row->barang_masuk); ?></td>
                                <td><?php echo e($row->barang_keluar); ?></td>
                                <td><?php echo e($row->kegiatan); ?></td>
                                <td>
                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->
            </form>
            <!-- end row -->
    </div> <!-- content -->
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('script'); ?>
    <script>
        var table = $('#datatable2').DataTable({
            "order": [[ 0, "desc" ]],
            dom: 'Bfrtip', 
            buttons: [
                {
                    extend: 'excelHtml5',
                    title: 'Laporan Buku Tamu',
                    text: 'Export To Excel',
                },
            ],
        });

        $('#checkboxlantai3').on('change', function(){
            table.draw();
        });

        $.fn.dataTable.ext.search.push(
                function( settings, data, dataIndex ) {
                    if($('#checkboxlantai3').is(":checked")){
                        if ((data[6] == "Ya"))
                        {
                            return true;
                        }
                        return false;
                    }
                    else{
                        return true;
                    }
                    
            });

    </script>
    <?php $__env->stopSection(); ?>
    </body>
</html>

<?php echo $__env->make('admin.master_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\imamn\Documents\Laravel\SSO\resources\views/admin/tamu.blade.php ENDPATH**/ ?>